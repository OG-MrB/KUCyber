IOC_list = [
  {
    "name": "WebMonitor RAT",
    "IPv4": "213.188.152.96",
    "FileHash-MD5": "c3973cd1e3ee7ab64b6ebeed5f9caf08",
    "URL": "https://213.188.152.96/recv7.php",
    "hostname": "dabmaster.wm01.to"
  },{
    "name": "Adwind RAT",
    "IPv4": "212.114.52.236",
    "FileHash-MD5": "1d77e96974e1e2301ed78cec19e8710b",
    "URL": "https://feylibertad.org/Amazon-PO20023938.jar",
    "hostname": "gwiza1988.hopto.org"
  },{
    "name": "PhantomLance",
    "domain": "taiphanmemfacebookmoi.info",
    "FileHash-MD5": "872a3dd2cd5e01633b57fa5b9ac4648d",
    "URL": "https://apk.support/app-en/com.codedexon.churchaddress",
    "hostname": "ps.andreagahuvrauvin.com"
  }
]

# Loop through the IOC_list one dictionary at a time
# The counter or index variable could be called anything
for IOC in IOC_list:
  # Picks an item from IOC_list
  # Loop through each dictionary's keys and associated values
  for key, value in IOC.items():
    # Print out the key and its value to the terminal
    print(key + ": " + str(value))

  # Add in a line between each new programmer in the list
  # Notice the indentation - this line is not part of nested loop
  print("------------------------")
