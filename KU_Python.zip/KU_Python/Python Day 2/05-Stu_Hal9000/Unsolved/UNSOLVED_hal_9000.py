# Create Welcome message

# Prompt for username


# Check if the user is root

    # If so, create a list, called '`commands`
    
    
    # Prompt the user for the command list
   
    
    # Check if the user's selection is in `commands`
    
        # If so, print: `Command accepted`
       
   
        # Print: `Invalid command`
        
        



    # If not, print: "Only root has access."
   
