# Create Welcome message
print('Welcome to Hal 2000!!!')
# Prompt for username
user_name = input("Enter username:  "))

# Check if the user is root
if user_name == 'root':
    # If so, create a list, called '`commands`
    commands = ["ls", "cd", "cat", "mv"]
    
    # Prompt the user the command list
    user_cmd = input("Enter command. ls, cd, cat, mv ")
    
    # Check if the user's selection is in `commands`
    if user_cmd in commands
        # If so, print: `Command accepted`
        print("Command accepted")
    else:
        # Print: `Invalid command`
        print("Invalid command")
        


else:
    # If not, print: "Only root has access."
    print('I\'m sorry '+ user_name + ', I\'m afraid I can\'t do that')
    print("Only root has access.")
