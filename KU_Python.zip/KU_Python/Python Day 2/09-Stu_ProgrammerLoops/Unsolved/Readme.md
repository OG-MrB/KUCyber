## Programmer Loops


### Instructions 

* Using the list of dictionaries in the file provided, do the following:

    * Loop through the `programmers_list` one dictionary at a time.

    * Loop through each of the dictionary's keys and values.

    * Print out each key and its associated value to the terminal.

    * Print out a line which will separate each programmer from the next.


* We added a lot of the code for you in the script file. Use the comments to help you with the rest. 
