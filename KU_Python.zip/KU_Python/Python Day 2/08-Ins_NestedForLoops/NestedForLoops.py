# A list of five letters
letter_list = ["B", "I", "N", "G", "O"]
# A list of 20 numbers
numbers_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

# The first loop moves through all the letters in the letter list
for letter in letter_list:

  # The second loop moves through all the numbers in the number list
  for number in numbers_list:

    # Print out the unique letter/number combination
    print(letter + str(number))

# Dictionary of Superheroe Weakness
supers_weakness = {
    "Superman": "Kryptonite",
    "Green Lantern": "Yellow",
    "Batman": "Unknown"
}

# The dictionary.keys() function places all of the keys of a dictionary into a list
key_list = supers_weakness.keys()
print("Super Heroes...")
for key in key_list:
  print(key)

# Use dictionay.values() to get a list of all the secret information
value_list = supers_weakness.values()
print("Their Weakness is...")
for value in value_list:
  print(value)

# Use dictionary.items() to get each key/value pair in a loop
for item, weakness in supers_weakness.items():
    print(item + " weakness is " + weakness + ".")
