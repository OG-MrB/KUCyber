import socket
target_host = '93.184.216.34'
target_port = 80

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

client.connect((target_host, target_port))

s = 'GET / HTTP/1.1\r\nHost: example.com\r\n\r\n'
client.send(s.encode(encoding='utf-8'))

response = client.recv(4096)

print(response)
