# Determine the IP Address on the **Virtual Machine**
ifconfig

# SSH Into the Virtual Machine from the **Local Machine**
# If on Mac add sudo to start of statement
scp poweruser@XXX.XXX.XXX.XXX:Extract.tar .

# Enter Password "grep"

# Untar file
tar -zvf Extract.tar