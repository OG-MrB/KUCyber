# Create a new file and fill it with a line of text
echo "Hey there! This is my sentence" > MyFile.txt

# Clear Pride.txt and insert replacement text
echo "Nope. Not a fan of Pride and Prejudice" > Pride.txt

# Add a line to the bottom of Alice.txt
echo "AhmedWuzHere." >> Alice.txt


