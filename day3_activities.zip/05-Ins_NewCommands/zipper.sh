# Create a Tar Archive of IRC_Logs
tar -cvf IRCLogs.tar IRC_Logs/

# Unarchive a Zip Folder
tar -xvf Gibberish_Folder.tar 