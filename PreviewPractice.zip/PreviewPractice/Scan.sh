# Use Head, Tail, and Less to scan through files in the folder
head -20 01-Rumi.txt
tail -20 02-Poe.txt
less 03-JungleBook.txt
less 04-Iliad.txt
